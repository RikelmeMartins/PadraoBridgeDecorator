package bridge.canal;

/** Implementor do Bridge: define COMO a mensagem é enviada. */
public interface CanalEnvio {
    void enviar(String destinatario, String titulo, String mensagem);
}
