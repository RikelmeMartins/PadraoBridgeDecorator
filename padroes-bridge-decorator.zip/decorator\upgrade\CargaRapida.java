package decorator.upgrade;

import decorator.arma.Arma;
import decorator.arma.TipoArma;

import java.util.EnumSet;

/** Reduz o tempo de recarga em 40%. Válida em todas as armas. */
public class CargaRapida extends UpgradeDecorator {
    public CargaRapida(Arma arma) {
        super(arma, "Carga rápida", 1_100, EnumSet.of(TipoArma.PISTOLA, TipoArma.METRALHADORA, TipoArma.BAZUCA));
    }

    @Override public double getTempoRecarga() { return arma.getTempoRecarga() * 0.6; }
}
