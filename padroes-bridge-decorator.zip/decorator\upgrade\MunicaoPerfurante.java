package decorator.upgrade;

import decorator.arma.Arma;
import decorator.arma.TipoArma;

import java.util.EnumSet;

/** Atravessa coletes e lataria: +25% de dano. Inválida em bazuca (usa foguetes). */
public class MunicaoPerfurante extends UpgradeDecorator {
    public MunicaoPerfurante(Arma arma) {
        super(arma, "Munição perfurante", 2_000, EnumSet.of(TipoArma.PISTOLA, TipoArma.METRALHADORA));
    }

    @Override public double getDano() { return arma.getDano() * 1.25; }
}
