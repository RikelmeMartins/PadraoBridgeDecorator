package decorator.upgrade;

import decorator.arma.Arma;
import decorator.arma.TipoArma;

import java.util.EnumSet;

/** Ilumina o alvo no escuro: +3 de precisão. Inválida em bazuca. */
public class Lanterna extends UpgradeDecorator {
    public Lanterna(Arma arma) {
        super(arma, "Lanterna tática", 300, EnumSet.of(TipoArma.PISTOLA, TipoArma.METRALHADORA));
    }

    @Override public int getPrecisao() { return limitarPrecisao(arma.getPrecisao() + 3); }
}
