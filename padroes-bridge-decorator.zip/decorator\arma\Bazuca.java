package decorator.arma;

public class Bazuca extends ArmaBase {
    public Bazuca() {
        // Tiro único: pente de 1 foguete.
        super("Bazuca", TipoArma.BAZUCA, 300, 40, 1, 4.0, 180, 25_000);
    }
}
