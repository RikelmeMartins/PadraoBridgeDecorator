package bridge.notificacao;

import bridge.canal.CanalEnvio;

/**
 * Abstraction do Bridge: define O QUE é enviado (o tipo de notificação).
 * Mantém uma referência ("a ponte") para o canal, que define COMO enviar.
 */
public abstract class Notificacao {
    protected CanalEnvio canal;

    protected Notificacao(CanalEnvio canal) {
        this.canal = canal;
    }

    /** Permite trocar o canal em tempo de execução. */
    public void setCanal(CanalEnvio canal) {
        this.canal = canal;
    }

    public abstract void notificar(String destinatario, String mensagem);
}
